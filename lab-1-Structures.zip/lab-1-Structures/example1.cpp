// today's agenda:
// What is a structure?
// working with structure
// typedef? but why...
// what is union? different?
// Enum....

#include<iostream>

using namespace std;
typedef struct person{
    string name;
    int reg;
    float height;

    void display(){
    cout << "Name : " << name << endl;
    cout << "Registration: " << reg << endl;
    cout << "Height : "<< height << endl;
    }
}pr;

int main(){
    person x;
    x.name = "Ali";
    x.reg = 123;
    x.height = 5.8;
    x.display();
    person y;
    cout << "Enter name: "<< endl;
    cin >> y.name;
    cout << "Enter Registration: "<< endl;
    cin >> y.reg;
    cout << " Enter Height: " << endl;
    cin >> y.height;
    
    y.display();
    pr z;
    z.name = "Saif";
    z.height = 6.2;
    z.reg = 223;
    z.display();
     
}