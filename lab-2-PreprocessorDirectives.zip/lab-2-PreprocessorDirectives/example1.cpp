/*
There are 4 types of Directives:
1. Macros
    Square Function
    Area of Circle
2. File Inclusion
    Demonstration Example
    GIK Cafe System
3. Conditional Directives
    #ifdef
    #if-else
4. Other Directives
*/

#include<iostream>
using namespace std;

#define PI 3.14
#define SQUARE(radius) (radius * radius)

int main(){
    int radius;
    cout << "Enter the Radius of this circle : " << endl;
    cin >> radius;
    cout << "The Area of this Circle is : " << PI * SQUARE(radius) << endl;
    
}