#include<iostream>
using namespace std;

void helper101(){
    int num = 5;
    for(int i=1;i<11;i++){
        cout << num << " X " << i << " = " << num * i << endl;
    }
}